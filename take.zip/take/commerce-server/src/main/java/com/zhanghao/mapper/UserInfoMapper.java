package com.zhanghao.mapper;

import com.zhanghao.dto.UserInfoDto;
import com.zhanghao.entity.UserInfoEntity;
import com.zhanghao.vo.UserInfoVO;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface UserInfoMapper {
    UserInfoVO selectById(Long id);

    List<UserInfoEntity> selectall();

    void updateUserInfo(UserInfoDto userInfoDto);
    @Select("select * from user where username=#{username}")
    UserInfoEntity getByUsername(String username);
    void star(Long id, Long userId);
}
