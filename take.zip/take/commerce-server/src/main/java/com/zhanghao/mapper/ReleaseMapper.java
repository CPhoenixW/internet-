package com.zhanghao.mapper;

import com.zhanghao.vo.ReleaseVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface ReleaseMapper {
    List<ReleaseVO> selectall();

    List<ReleaseVO> selectByKeyword();


    void starUpdate(Long id);
}
