package com.zhanghao.service;

import com.zhanghao.dto.UserInfoDto;
import com.zhanghao.dto.UserLoginDTO;
import com.zhanghao.entity.UserInfoEntity;
import com.zhanghao.vo.UserInfoVO;

import java.util.List;

public interface UserInfoService {
    UserInfoVO selectById(Long id);

    List<UserInfoEntity> selectall();

    void updateUserInfo(UserInfoDto userInfoDto);

    UserInfoEntity login(UserLoginDTO userLoginDTO);

    void star(Long id, Long userId);
}
