package com.zhanghao.controller.admin;

import com.zhanghao.constant.JwtClaimsConstant;
import com.zhanghao.properties.JwtProperties;
import com.zhanghao.result.Result;
import com.zhanghao.service.UserInfoService;
import com.zhanghao.utils.JwtUtil;
import com.zhanghao.dto.ReleaseDTO;
import com.zhanghao.dto.UserInfoDto;
import com.zhanghao.dto.UserLoginDTO;
import com.zhanghao.entity.UserInfoEntity;
import com.zhanghao.vo.UserInfoVO;
import com.zhanghao.vo.UserLoginVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api")
@Slf4j
public class UserInfoController {
    @Autowired
    UserInfoService userInfoService;
    @Autowired
    JwtProperties jwtProperties;
    @PostMapping("/login")
    public Result<UserLoginVO> login(@RequestBody UserLoginDTO userLoginDTO) {
        log.info("用户登录：{}", userLoginDTO);
        UserInfoEntity user=userInfoService.login(userLoginDTO);
        //登录成功后，生成jwt令牌
        Map<String, Object> claims = new HashMap<>();
        claims.put(JwtClaimsConstant.EMP_ID, user.getId());
        String token = JwtUtil.createJWT(
                jwtProperties.getAdminSecretKey(),
                jwtProperties.getAdminTtl(),
                claims);

        UserLoginVO userLoginVO = UserLoginVO.builder()
                .id(user.getId())
                .username(user.getUsername())
                .name(user.getName())
                .token(token)
                .build();

        return Result.success(userLoginVO);
    }
    @GetMapping("/userinfo/{id}")
    public Result<UserInfoVO> getUserInfo(@PathVariable Long id){
        log.info("根据id:{},查询用户信息",id);
        UserInfoVO userInfo=userInfoService.selectById(id);
        return Result.success(userInfo);
    }

    @GetMapping("/userinfo")
    public Result<List<UserInfoEntity>> selectall(){
        log.info("查询所有用户信息");
        return Result.success(userInfoService.selectall());
    }
    @PutMapping("/infochange")
    public Result<String> updateUserInfo(@RequestBody UserInfoDto userInfoDto){
        log.info("修改用户信息:{}",userInfoDto);
        userInfoService.updateUserInfo(userInfoDto);
        return Result.success("修改成功");
    }
    /*@GetMapping("/users/{userId}/favorites")
    public Result<String> getFavorites(@PathVariable Long userId){
        log.info("查询用户收藏夹");
        userInfoService.getFavorites(userId);
        return Result.success("查询成功");
    }*/
    @PostMapping("/posts/{id}/like")
    public Result<String> star(@PathVariable Long id, @RequestBody ReleaseDTO releaseDTO){
        log.info("点赞");
        userInfoService.star(id,releaseDTO.getUserId());
        return Result.success("点赞成功");
    }


}
