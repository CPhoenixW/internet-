package com.zhanghao.controller.admin;

import com.zhanghao.result.Result;
import com.zhanghao.service.ReleaseService;
import com.zhanghao.entity.QueryParamEntity;
import com.zhanghao.vo.ReleaseVO;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RequestMapping("/recommendations")
@RestController
@Slf4j
public class CommunityController {
    @Autowired
    ReleaseService releaseService;
    @GetMapping("/recommendations/{id}")
    public Result<List<ReleaseVO>> getRecommendations(@PathVariable Long id) {
        log.info("获取资源列表");
        List<ReleaseVO> releaseVO=releaseService.selectall();
        return Result.success(releaseVO);
    }
    @GetMapping("/serch")
    public Result<List<ReleaseVO>> getByKeyword(@RequestBody QueryParamEntity queryParamEntity) {
        log.info("根据关键词:,{}",queryParamEntity.getKeyword());
        List<ReleaseVO> releaseVO=releaseService.selectByKeyword();
        return Result.success(releaseVO);
    }


}
