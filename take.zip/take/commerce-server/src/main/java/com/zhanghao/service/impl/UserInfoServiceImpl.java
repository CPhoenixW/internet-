package com.zhanghao.service.impl;

import com.zhanghao.constant.MessageConstant;
import com.zhanghao.constant.StatusConstant;
import com.zhanghao.exception.AccountLockedException;
import com.zhanghao.exception.AccountNotFoundException;
import com.zhanghao.exception.PasswordErrorException;
import com.zhanghao.mapper.UserInfoMapper;
import com.zhanghao.service.ReleaseService;
import com.zhanghao.service.UserInfoService;
import com.zhanghao.dto.UserInfoDto;
import com.zhanghao.dto.UserLoginDTO;
import com.zhanghao.entity.UserInfoEntity;
import com.zhanghao.vo.UserInfoVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.DigestUtils;

import java.util.List;

@Service
public class UserInfoServiceImpl implements UserInfoService {
    @Autowired
    UserInfoMapper userInfoMapper;
    @Autowired
    ReleaseService releaseService;
    @Override
    public UserInfoVO selectById(Long id) {
        return userInfoMapper.selectById(id);
    }

    @Override
    public List<UserInfoEntity> selectall() {
        return userInfoMapper.selectall();
    }

    @Override
    public void updateUserInfo(UserInfoDto userInfoDto) {
        userInfoMapper.updateUserInfo(userInfoDto);
    }

    @Override
    public UserInfoEntity login(UserLoginDTO userLoginDTO) {
        String username = userLoginDTO.getUsername();
        String password = userLoginDTO.getPassword();

        //1、根据用户名查询数据库中的数据
        UserInfoEntity user =userInfoMapper.getByUsername(username);
        //2、处理各种异常情况（用户名不存在、密码不对、账号被锁定）
        if (user == null) {
            //账号不存在
            throw new AccountNotFoundException(MessageConstant.ACCOUNT_NOT_FOUND);
        }

        //密码比对
        //进行md5加密，然后再进行比对
        password = DigestUtils.md5DigestAsHex(password.getBytes());
        if (!password.equals(user.getPassword())) {
            //密码错误
            throw new PasswordErrorException(MessageConstant.PASSWORD_ERROR);
        }

        if (user.getStatus() == StatusConstant.DISABLE) {
            //账号被锁定
            throw new AccountLockedException(MessageConstant.ACCOUNT_LOCKED);
        }

        //3、返回实体对象
        return user;
    }

    @Override
    @Transactional
    public void star(Long id, Long userId) {

        //操作喜欢表
        userInfoMapper.star(id,userId);

        //操作作品表
        releaseService.starUpdate(id);
    }
}
