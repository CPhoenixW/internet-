package com.zhanghao.controller.admin;

import com.zhanghao.constant.MessageConstant;
import com.zhanghao.result.Result;
import com.zhanghao.utils.AliOssUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.UUID;

//文件上传通用接口
@RestController
@RequestMapping("/api/avatarchange")
@Slf4j
public class AliYunFileController {
    @Autowired
    AliOssUtil aliOssUtil;
    @PostMapping()
    public Result<String> upload(MultipartFile file){
        log.info("文件上传");
        try {
            String originalFilename = file.getOriginalFilename();
            //文件的绝对路径

            String dir = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy/MM"));
            //生成一个新的不重复的文件名
            String newFileName = UUID.randomUUID() + originalFilename.substring(originalFilename.lastIndexOf("."));
            String objectName = "Personal"+dir + "/" + newFileName;

            String path = aliOssUtil.upload(file.getBytes(), objectName);
            return Result.success(path);
        } catch (IOException e) {
            log.info("文件上传失败:"+e);
        }
        return Result.error(MessageConstant.UPLOAD_FAILED);
    }
}
