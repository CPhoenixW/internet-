package com.zhanghao.service.impl;

import com.zhanghao.mapper.ReleaseMapper;
import com.zhanghao.service.ReleaseService;
import com.zhanghao.vo.ReleaseVO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ReleaseServiceImpl implements ReleaseService {
    @Autowired
    ReleaseMapper releaseMapper;

    @Override
    public List<ReleaseVO> selectall() {
        return releaseMapper.selectall();
    }

    @Override
    public List<ReleaseVO> selectByKeyword() {
        return releaseMapper.selectByKeyword();
    }

    @Override
    public void starUpdate(Long id) {
        releaseMapper.starUpdate(id);
    }
}
