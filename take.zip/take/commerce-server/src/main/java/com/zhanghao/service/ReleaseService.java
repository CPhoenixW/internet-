package com.zhanghao.service;

import com.zhanghao.vo.ReleaseVO;

import java.util.List;

public interface ReleaseService {
    List<ReleaseVO> selectall();

    List<ReleaseVO> selectByKeyword();


    void starUpdate(Long id);
}
