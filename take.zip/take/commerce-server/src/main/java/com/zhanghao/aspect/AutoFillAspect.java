package com.zhanghao.aspect;

import com.zhanghao.ano.Autofill;
import com.zhanghao.constant.AutoFillConstant;
import com.zhanghao.context.BaseContext;
import com.zhanghao.enumeration.OperationType;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.stereotype.Component;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.time.LocalDateTime;

//自定义切面类
@Aspect
@Component
@Slf4j
public class AutoFillAspect {
    @Pointcut("execution(* com.zhanghao.mapper.*.*(..)) && @annotation(com.zhanghao.ano.Autofill)")
    public void autoFillPoint(){

    }
    @Before("autoFillPoint()")
    public void autoFill(JoinPoint joinPoint) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
        log.info("公共字段自动填充");
        MethodSignature signature = (MethodSignature) joinPoint.getSignature();
        Autofill annotation = signature.getMethod().getAnnotation(Autofill.class);
        OperationType value = annotation.value();
        Object[] args = joinPoint.getArgs();
        if (args==null || args.length==0){
            return;
        }
        Object arg = args[0];
        if (value==OperationType.INSERT){
            //这里调用定义了的常量，防止写错
            Method setCreateTime = arg.getClass().getDeclaredMethod(AutoFillConstant.SET_CREATE_TIME, LocalDateTime.class);
            Method setCreateUser = arg.getClass().getDeclaredMethod(AutoFillConstant.SET_CREATE_USER, Long.class);
            Method setUpdateTime = arg.getClass().getDeclaredMethod(AutoFillConstant.SET_UPDATE_TIME, LocalDateTime.class);
            Method setUpdateUser = arg.getClass().getDeclaredMethod(AutoFillConstant.SET_UPDATE_USER, Long.class);
            //当前User
            setCreateTime.invoke(arg,LocalDateTime.now());
            setCreateUser.invoke(arg, BaseContext.getCurrentId());
            setUpdateTime.invoke(arg,LocalDateTime.now());
            setUpdateUser.invoke(arg,BaseContext.getCurrentId());

        }
        else {
            Method setUpdateTime = arg.getClass().getDeclaredMethod("setUpdateTime", LocalDateTime.class);
            Method setUpdateUser = arg.getClass().getDeclaredMethod("setUpdateUser", Long.class);
            setUpdateTime.invoke(arg,LocalDateTime.now());
            setUpdateUser.invoke(arg,BaseContext.getCurrentId());
        }
    }
}
