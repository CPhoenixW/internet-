package com.zhanghao.test;

import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.json.JSONException;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;

import java.io.IOException;

public class SpringDataRedisTest {
    /**
     * 通过httpclient发送get请求
     */
    @Test
    public void test() throws IOException {
        //创建httpclient对象
        CloseableHttpClient aDefault = HttpClients.createDefault();
        //创建请求对象
        HttpGet httpGet = new HttpGet("http://localhost:8080/user/shop/status");
        //发送请求
        CloseableHttpResponse response = aDefault.execute(httpGet);

        //获取返回状态码
        int statusCode = response.getStatusLine().getStatusCode();
        System.out.println("返回的状态码为:"+statusCode);
        //获取返回响应体
        HttpEntity entity = response.getEntity();
        String string = EntityUtils.toString(entity);
        System.out.println("响应体为:"+string);
        //关闭资源
        response.close();
        aDefault.close();

    }
    @Test
    public void test1() throws IOException, JSONException {
        //创建httpclient对象
        CloseableHttpClient httpClient = HttpClients.createDefault();
        //创建请求对象
        HttpPost httpPost = new HttpPost("http://localhost:8080/admin/employee/login");

        //设置请求参数
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("username","admin");
        jsonObject.put("password","456789");
        StringEntity stringEntity = new StringEntity(jsonObject.toString());
        //指定编码方式
        stringEntity.setContentEncoding("utf-8");
        stringEntity.setContentType("application/json");
        httpPost.setEntity(stringEntity);//封装数据

        //发送请求
        CloseableHttpResponse response = httpClient.execute(httpPost);
        //解析数据
        int statusCode = response.getStatusLine().getStatusCode();
        System.out.println("返回的状态码为:"+statusCode);
        HttpEntity entity = response.getEntity();
        String string = EntityUtils.toString(entity);
        System.out.println("响应体为:"+string);

        //关闭资源
        response.close();
        httpClient.close();
    }
}
