package com.zhanghao.test;

import org.junit.jupiter.api.Test;

public class Leecode {
    @Test
    public void suanfa(){

    }
}
