package com.zhanghao.entity;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserInfoEntity implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;
    private String openId;
    private String name;
    private String wechat;
    private String bio;
    private Integer age;
    private String location;
    private String zodiac;
    private String signature;
    private String username;
    private String password;
    private String email;
    private String phone;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDate birthday;
    private String profilePictureUrl;
    private Integer status;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String createTime;
    @JsonFormat(pattern = "yyyy-MM-dd")
    private String updateTime;
}
