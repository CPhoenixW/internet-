package com.zhanghao.entity;

import lombok.Data;

import java.io.Serializable;
@Data
public class QueryParamEntity implements Serializable {
    private Long id;
    private String keyword;
}
