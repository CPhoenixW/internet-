package com.zhanghao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.time.LocalDateTime;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class UserInfoVO  implements Serializable {
    private static final long serialVersionUID = 1L;
    private Long id;          // 用户ID
    private String name;        // 用户名
    private String email;      // 电子邮箱
    private String wechat;     // 微信账号
    private String phone;      // 手机号

    @JsonFormat(pattern = "yyyy-MM-dd")
    private LocalDateTime birthday;     // 生日

    private Integer age;       // 年龄
    private String avatar;     // 头像URL
    private String bio;        // 个人简介
    private String location;   // 所在地
    private String zodiac;     // 星座
    private String signature;  // 个性签名
}
