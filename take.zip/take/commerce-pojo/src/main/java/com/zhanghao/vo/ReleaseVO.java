package com.zhanghao.vo;

import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ReleaseVO implements Serializable {
    private Long id;
    private String authorId;
    private String authorName;
    private String title;
    private String content;
    private String imgUrl;
    private String type;
    private int stars;
    private int comments;
    private int views;
    private int favorites;
    private String status;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    private String createTime;
}
