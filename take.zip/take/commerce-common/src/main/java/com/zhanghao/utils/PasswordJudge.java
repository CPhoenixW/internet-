package com.zhanghao.utils;

import java.util.regex.Pattern;

public class PasswordJudge {
    private static final String PASSWORD_REGEX = "^[a-zA-Z0-9]+$";
    private static final Pattern PASSWORD_PATTERN = Pattern.compile(PASSWORD_REGEX);
    public static boolean judge(String password){
        if (password.length()<=20&&password.length()>=6){
            return PASSWORD_PATTERN.matcher(password).matches();
        }
        return false;
    }
}
